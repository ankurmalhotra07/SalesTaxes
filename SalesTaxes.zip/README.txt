Run unit test in:
SalesTaxesUnitTest

I have used SOLID principles where ever I can. Some improvements that I would have made if I had more time:
Create interface for TaxCalculationService. 
Extract rounding logic into its own class.
Extract formatting logic into its own class and create an interface.
Read input data from file, instead of hardcoding.
Constants can be moved into a config file.
Use dependancy injection (constructor).
Need more unit tests.
Use regex to extract quantities, name etc
The above changes will make the system a lot easier to maintain and extend.

Thanks for the opportunity. I had fun completing this assignment!

