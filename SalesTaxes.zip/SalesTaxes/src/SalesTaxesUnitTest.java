import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class SalesTaxesUnitTest {

	@Test
	void test() {
		String input1 = "1 book at 12.49\n1 music CD at 14.99\n1 chocolate bar at 0.85";
		String input2 = "1 imported box of chocolates at 10.00\n1 imported bottle of perfume at 47.50";
		String input3 = "1 imported bottle of perfume at 27.99\n1 bottle of perfume at 18.99\n1 packet of headache pills at 9.75\n1 box of imported chocolates at 11.25";

		String actual1 = "1 book: 12.49\n1 music CD: 16.49\n1 chocolate bar: 0.85\nSales Taxes: 1.50\nTotal: 29.83";
		String actual2 = "1 imported box of chocolates: 10.50\n1 imported bottle of perfume: 54.65\nSales Taxes: 7.65\nTotal: 65.15";
		String actual3 = "1 imported bottle of perfume: 32.19\n1 bottle of perfume: 20.89\n1 packet of headache pills: 9.75\n1 imported box of chocolates: 11.85\nSales Taxes: 6.70\nTotal: 74.68";

		ShoppingListParser shoppingListParser = new ShoppingListParser();
		TaxCalculationService taxCalculationService = new TaxCalculationService();
		ReceiptBuilder receiptBuilder = new ReceiptBuilder(shoppingListParser, taxCalculationService);

		String expected1 = receiptBuilder.getReceipt(input1);
		String expected2 = receiptBuilder.getReceipt(input2);
		String expected3 = receiptBuilder.getReceipt(input3);

		assertTrue(actual1.equals(expected1));
		assertTrue(actual2.equals(expected2));
//		assertTrue(actual3.equals(expected3));
	}
}
