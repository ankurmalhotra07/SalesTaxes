import org.apache.commons.lang3.StringUtils;

public class ShoppingListParser {

	public ShoppingList Parse(String inputs) {

		ShoppingList shoppingList = new ShoppingList();
		String[] items = inputs.split("\n");
		for (String input : items) {

			String[] inputAry = input.split(" ");
			int quantity = ExtractQuantity(inputAry);
			String itemName = ExtractItemName(input);
			double price = ExtarctPrice(input);
			boolean isImported = IsImported(input);
			if (isImported) {
				String modified = itemName.replace(" imported ", " ");
				itemName = modified.trim();
				itemName = " imported "+itemName;
			}
			boolean isExemptFromStandardTax = IsExemptFromStandardTax(input);
			Item itm = new Item(quantity, itemName, price, isImported, isExemptFromStandardTax);
			shoppingList.AddItem(itm);

		}
		return shoppingList;
	}

	private double ExtarctPrice(String input) {
		String[] ary = input.split(" at ");
		String price = ary[1];
		return Double.parseDouble(price);
	}

	private boolean IsExemptFromStandardTax(String input) {
		if (input.contains("chocolate")) {
			return true;
		}
		if (input.contains("book")) {
			return true;
		}
		if (input.contains("pill")) {
			return true;
		}
		return false;
	}

	private String ExtractItemName(String input) {
		String[] inputAry = input.split(" ");
		String name = StringUtils.substringBetween(input, inputAry[0], " at ");
		return name;
	}

	private int ExtractQuantity(String[] input) {
		return Integer.parseInt(input[0]);
	}

	private boolean IsImported(String input) {
		return input.contains(" imported ");
	}

}
