
public class ReceiptItem {

	private Item item;
	private double tax;

	public ReceiptItem(Item itm, double tax) {
		this.tax = tax;
		this.item = itm;
	}

	public int getQuantity() {
		return item.getQuantity();
	}

	public String getItemName() {
		return item.getItemName();
	}

	public double getPrice() {
		return item.getPrice() + tax;
	}

	public boolean IsImported() {
		return item.IsImported();
	}
}
