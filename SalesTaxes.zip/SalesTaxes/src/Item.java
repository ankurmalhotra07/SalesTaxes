
public class Item {

	private final int quantity;
	private final String itemName;
	private final double price;
	private final boolean isImported;
	private final boolean isExemptFromStandardTax;

	public Item(int quantity, String itemName, double price, boolean isImported, boolean isExemptFromStandardTax) {
		this.quantity = quantity;
		this.itemName = itemName;
		this.price = price;
		this.isImported = isImported;
		this.isExemptFromStandardTax = isExemptFromStandardTax;
	}

	public int getQuantity() {
		return quantity;
	}

	public String getItemName() {
		return itemName;
	}

	public double getPrice() {
		return price;
	}

	public boolean IsImported() {
		return isImported;
	}

	public boolean IsExemptFromStandardTax() {
		return isExemptFromStandardTax;
	}

}
