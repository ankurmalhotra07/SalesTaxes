
public class ReceiptBuilder {

	private ShoppingListParser shoppingListParser;
	private TaxCalculationService taxCalculationService;

	public ReceiptBuilder(ShoppingListParser shoppingListParser, TaxCalculationService taxCalculationService) {
		this.shoppingListParser = shoppingListParser;
		this.taxCalculationService = taxCalculationService;

	}

	public String getReceipt(String input) {
		ShoppingList shoppingList = shoppingListParser.Parse(input);
		Receipt receipt = new Receipt(shoppingList, taxCalculationService);
		return receipt.BuildReceipt();
	}

}
