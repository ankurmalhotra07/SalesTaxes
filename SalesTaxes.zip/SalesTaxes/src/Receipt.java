import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class Receipt {

	private double total;
	private double totalTaxes;
	private List<ReceiptItem> receiptItems = new ArrayList<ReceiptItem>();

	public Receipt(ShoppingList shopingList, TaxCalculationService taxCalculationService) {

		for (Item itm : shopingList.GetItems()) {
			double tax = taxCalculationService.getTax(itm);
			ReceiptItem receiptItm = new ReceiptItem(itm, tax);
			receiptItems.add(receiptItm);
			totalTaxes += tax;
			total += receiptItm.getPrice();
		}
	}

	public String BuildReceipt() {
		DecimalFormat df = new DecimalFormat("####0.00");
		StringBuffer result = new StringBuffer();
		for (ReceiptItem item : receiptItems) {
			result.append(item.getQuantity());
			result.append(item.getItemName());
			result.append(": ");
			result.append((df.format(item.getPrice())));
			result.append("\n");
		}
		result.append("Sales Taxes: ");
		result.append(df.format(totalTaxes));
		result.append("\n");
		result.append("Total: ");
		result.append(df.format(total));

		return result.toString();
	}

}
