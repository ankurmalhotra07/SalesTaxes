

public class TaxCalculationService {

	private final double SALES_TAX_RATE = 0.10d;

	private final double IMPORT_TAX_RATE = 0.05d;

	public double Calculate(ShoppingList shoppingList) {
		return 0;

	}

	public double getTax(Item itm) {
		double tax = 0;
		if (!itm.IsExemptFromStandardTax())
			tax += getSalesTax(itm.getPrice(), itm.getQuantity());
		if (itm.IsImported())
			tax += getImportTax(itm.getPrice(), itm.getQuantity());
		return RoundOff(tax);
	}

	private double RoundOff(double value) {
		double rounded = Math.round(value * 20.0) / 20.0;
		return rounded;
	}

	private double getSalesTax(double price, int quantity) {
		return quantity * (price * SALES_TAX_RATE);
	}

	private double getImportTax(double price, int quantity) {
		return quantity * (price * IMPORT_TAX_RATE);
	}

}
