import java.util.ArrayList;
import java.util.List;

public class ShoppingList {

	private List<Item> items = new ArrayList<Item>();

	public void AddItem(Item itm) {
		items.add(itm);
	}

	public List<Item> GetItems() {
		return items;
	}

}
